module.exports =  {
    "MJ_APIKEY_PUBLIC": "8a4e434bf624f928e6ef6121b956cd45",
    "MJ_APIKEY_PRIVATE": "3ab9f19f90e1bb19705eaaefc87e677b",
    "MJ_SENDER_MAIL": "divakar685@gmail.com",
    "MJ_SENDER_NAME": "Divakar"
};